package in.ineuron.dependent;

public interface ICourseMaterial {
	public String courseContent();
	public double price();
}
